window.addEventListener("DOMContentLoaded", (event) => {
  const user = localStorage.getItem("user");
  console.log("REE USER", user);
});
